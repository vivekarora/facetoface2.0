body.mod-facetoface table.f2fsession td.c0 {
    font-weight: bold;
}
body.mod-facetoface table.f2fsession td.c1 {
    width: 100%;
}
body#mod-facetoface-signup div#content div.generalbox {
    text-align: center;
}
body#mod-facetoface-view div#content div.generalbox {
    text-align: center;
}
body#mod-facetoface-view div#content div.generalbox div#description {
    text-align: left;
}
body#mod-facetoface-attendees div#content div.generalbox {
    text-align: center;
}
tr.highlight td.cell {
    background-color: #AAFFAA;
}
a.f2fsessionlinks, td.f2fsessionnotice, span.f2fsessionnotice {
    font-size: 11px;
    font-weight: bold;
    line-height: 14px;
}
