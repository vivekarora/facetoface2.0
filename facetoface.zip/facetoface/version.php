<?php

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2010080302;   // The (date) version of this module
$module->requires = 2010080300;  // Requires this Moodle version
$module->cron     = 60;          // How often should cron check this module (seconds)?
