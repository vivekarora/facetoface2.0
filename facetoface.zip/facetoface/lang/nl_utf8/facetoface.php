<?php // facetoface.php - created with Moodle 1.9 Beta 3 (2007101504)
      //
      // Created by Peter-Anne Wissema <wis AT veursvoorburg DOT nl>
      // Released under the same terms as the Facetoface module

