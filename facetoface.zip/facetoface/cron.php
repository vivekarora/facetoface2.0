<?php

require_once '../../config.php';
require_once 'lib.php';

facetoface_cron();
